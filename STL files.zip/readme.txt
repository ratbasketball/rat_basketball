


The following is a list of 3d printed components available as .stl files in this directory:

hoop components:

	hoop.stl
	
	sensor arm v3.stl or sensor arm v4.stl
		Sensor arm v4 provides an inverted signal, while remaining otherwise identical to sensor arm v3.  
		
General components:

	pellet duct.stl: This allows the trainer to pass pellets or food to the rats
	
	get light filter slot.stl:  This part allows you to slide a gel light filter in front of an led light, to change the stimuli color.

All objects have been tested printed at 100% infill.  